import React from 'react'
import Home from '../../../components/petboarding/user/boardings';
import Navbar from '../../../components/petboarding/user/sidebar/Cnavbar';

function Dashboard() {
  return (
    <>
    <Navbar/>
    <Home/>
    </>
  )
}

export default Dashboard