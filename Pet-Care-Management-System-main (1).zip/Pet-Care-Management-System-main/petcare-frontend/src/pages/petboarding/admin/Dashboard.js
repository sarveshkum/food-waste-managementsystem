import React from 'react'
import Home from '../../../components/petboarding/admin/home';
import Navbar from '../../../components/petboarding/admin/sidebar/Navbar';

function Dashboard() {
  return (
    <>
    <Navbar/>
    <Home/>
    </>
  )
}

export default Dashboard