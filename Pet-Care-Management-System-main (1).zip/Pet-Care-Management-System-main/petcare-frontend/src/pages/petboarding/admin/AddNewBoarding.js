import React from 'react'
import Insert from '../../../components/petboarding/admin/insert';
import Navbar from '../../../components/petboarding/admin/sidebar/Navbar';

function AddNewBoarding() {
  return (
    <>
    <Navbar/>
    <Insert/>
    </>
  )
}

export default AddNewBoarding