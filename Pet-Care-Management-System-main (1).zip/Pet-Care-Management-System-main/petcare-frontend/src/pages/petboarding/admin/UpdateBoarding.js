import React from 'react'
import Update from '../../../components/petboarding/admin/update';
import Navbar from '../../../components/petboarding/admin/sidebar/Navbar';

function AddNewBoarding() {
  return (
    <>
    <Navbar/>
    <Update/>
    </>
  )
}

export default AddNewBoarding