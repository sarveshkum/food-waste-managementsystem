import React from 'react'

const InputBox = () => {
  return (
    <div>InputBox</div>
  )
}

export default InputBox