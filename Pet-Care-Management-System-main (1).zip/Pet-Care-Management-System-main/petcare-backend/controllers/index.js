exports.index = (req, res) => {
    res.send("Index route")
}